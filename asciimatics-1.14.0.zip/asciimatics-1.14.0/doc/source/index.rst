.. asciimatics documentation master file, created by
   sphinx-quickstart on Fri Apr  3 17:57:45 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to asciimatics' documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2

   intro
   contributing
   io
   rendering
   animation
   widgets
   troubleshooting
   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

