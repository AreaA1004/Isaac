If you'd like to contribute to this project, see 
http://asciimatics.readthedocs.org/en/latest/contributing.html for details.
