nosetests --with-coverage --cover-package=asciimatics

