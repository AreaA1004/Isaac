
cd doc && cp source/conf_orig.py source/conf.py && ./build.sh
