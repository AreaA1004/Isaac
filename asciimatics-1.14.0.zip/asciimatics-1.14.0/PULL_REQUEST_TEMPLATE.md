# Thanks for taking the time to contibute to this project.  You are a star!

Checks
------
_Before you go any further, please make sure that you have read the [contributing guidelines](https://asciimatics.readthedocs.io/en/latest/contributing.html), run the test suite and that your clone of this repository was taken after 18 October 2018.  (I had to fix up the git history and so clones before that date will have all sorts of merge issues)._ 

_Now please delete this pre-amble section and fill in the rest of the template..._

Issues fixed by this PR
-----------------------
_Please list any Issues here_

What does this implement/fix?
-----------------------------
_Please add any further information about the fix if it is not obvious from the related Issue above_

Any other comments?
-------------------
_If there is anything else you feel you need to add, please do so here!_
